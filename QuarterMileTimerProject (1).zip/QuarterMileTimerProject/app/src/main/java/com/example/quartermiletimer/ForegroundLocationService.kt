package com.example.quartermiletimer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager

class ForegroundLocationService : Service(), SensorEventListener {
    companion object {
        const val CHANNEL_ID = "qmt_channel"
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val TARGET_METERS = 402.0f
    }

    private lateinit var fusedClient: FusedLocationProviderClient
    private lateinit var locationRequest: LocationRequest
    private var lastLocation: Location? = null
    private var cumulativeDistance = 0f
    private var runStartTime: Long = 0L
    private var runActive = false

    // accelerometer
    private var sensorManager: SensorManager? = null
    private var accelSensor: Sensor? = null

    override fun onCreate() {
        super.onCreate()
        fusedClient = LocationServices.getFusedLocationProviderClient(this)
        locationRequest = LocationRequest.create().apply {
            interval = 100 // 100ms ~ 10Hz
            fastestInterval = 100
            priority = LocationRequest.PRIORITY_HIGH_ACCURACY
            maxWaitTime = 0
        }

        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        accelSensor = sensorManager?.getDefaultSensor(Sensor.TYPE_LINEAR_ACCELERATION)

        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startForegroundWithNotification()
            ACTION_STOP -> stopForeground(true).also { stopSelf() }
        }
        return START_STICKY
    }

    private fun startForegroundWithNotification() {
        val notif = buildNotification("Tracking GPS at ~10Hz")
        startForeground(1, notif)
        startLocationUpdates()
        sensorManager?.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_GAME)
    }

    private fun buildNotification(text: String): Notification {
        val notificationIntent = Intent(this, MainActivity::class.java)
        val pending = PendingIntent.getActivity(this, 0, notificationIntent, PendingIntent.FLAG_IMMUTABLE)
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Quarter Mile Timer")
            .setContentText(text)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pending)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val chan = NotificationChannel(CHANNEL_ID, "QMT Channel", NotificationManager.IMPORTANCE_LOW)
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(chan)
        }
    }

    private val callback = object: LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            for (loc in result.locations) {
                handleLocation(loc)
            }
        }
    }

    private fun startLocationUpdates() {
        fusedClient.requestLocationUpdates(locationRequest, callback, mainLooper)
    }

    private fun stopLocationUpdates() {
        fusedClient.removeLocationUpdates(callback)
        sensorManager?.unregisterListener(this)
    }

    private fun handleLocation(loc: Location) {
        if (!runActive) {
            lastLocation = loc
            return
        }

        val prev = lastLocation
        if (prev != null) {
            val d = prev.distanceTo(loc)
            cumulativeDistance += d
            if (cumulativeDistance >= TARGET_METERS) {
                val elapsed = SystemClock.elapsedRealtimeNanos() - runStartTime
                val elapsedMs = elapsed / 1_000_000.0
                onRunFinished(elapsedMs, loc)
                runActive = false
            }
        }
        lastLocation = loc
    }

    private fun onRunFinished(elapsedMs: Double, loc: Location) {
        val timeSec = elapsedMs / 1000.0
        val speedMps = loc.speed
        val speedKph = speedMps * 3.6
        val notif = buildNotification(String.format("Run: %.3fs — trap: %.1f km/h", timeSec, speedKph))
        val nm = getSystemService(NotificationManager::class.java)
        nm.notify(2, notif)

        cumulativeDistance = 0f
        lastLocation = null
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type != Sensor.TYPE_LINEAR_ACCELERATION) return
        val ax = event.values[0]
        val ay = event.values[1]
        val az = event.values[2]
        val mag = Math.sqrt((ax*ax + ay*ay + az*az).toDouble()).toFloat()

        if (!runActive && mag > 2.0f) {
            runActive = true
            runStartTime = SystemClock.elapsedRealtimeNanos()
            cumulativeDistance = 0f
            lastLocation = null
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        stopLocationUpdates()
        super.onDestroy()
    }
}
